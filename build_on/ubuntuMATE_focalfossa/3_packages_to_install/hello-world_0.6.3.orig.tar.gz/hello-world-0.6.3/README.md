#### "Hello World" in C++...

Actually, this project has turned into something greater.  
  
It happened so that, while reading the materials about C++, I found a good review about IDEs and build systems 
for C++, after reading which I've chosen to work with qt-creator as IDE/editor and with SCons as build system...  
  
I've liked much that SCons is not just another build system, but a *build system creation kit*. In my humble opinion, in 
this sense it is similar to Gentoo which is not just another distro, but a *meta-distro*, or a *distro designer*, in which 
you must make all the decisions yourself and which gives you maximum flexibility.  
  
SCons is also good for learning what job a Gentoo (or other distro's) maintainer of a package should do in order to get the 
package built and installed correctly. I would like to write the SCons script so that maintainers (at least Gentoo's) do 
not have to patch it.  
  
In short, it turned into a project of learning more Python, SCons and Linux in general :)  
  
There is a file docs/used_sources with a listing of all main materials that I've looked at during the work on this project.
